<?php
include("connMedic.php");

$sql ="UPDATE doctor SET
DoctorName='$_POST[Name]',
DoctorIC='$_POST[ic]',
DoctorAge='$_POST[age]',
Gender='$_POST[gender]',
DoctorEmailAddress='$_POST[mail]',
Telephone='$_POST[telephone]',
SpecialtyName='$_POST[spec]',
DoctorPassword='$_POST[pass]',
s

WHERE DoctorID=$_POST[DoctorID];";

echo $sql;

if (mysqli_query($con, $sql)){
    mysqli_close($con);
    header("Location:viewDocSetting.php");
}

?>