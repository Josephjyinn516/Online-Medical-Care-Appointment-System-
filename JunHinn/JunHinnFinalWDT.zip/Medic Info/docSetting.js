function scrolll(){
    var left = document.querySelector(".scroll-images");
    left.scrollBy(350, 0);
}

function scrollr(){
    var right = document.querySelector(".scroll-images");
    right.scrollBy(350, 0)
}